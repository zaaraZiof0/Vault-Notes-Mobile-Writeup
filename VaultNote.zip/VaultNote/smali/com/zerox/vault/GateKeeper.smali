.class public Lcom/zerox/vault/GateKeeper;
.super Ljava/lang/Object;

.method public static getMask()Ljava/lang/String;
    .registers 1
    const-string v0, "1d100e105e542778"
    return-object v0
.end method

.method public static getKey()Ljava/lang/String;
    .registers 1
    const-string v0, "d3x://vault"
    return-object v0
.end method

.method public static note()Ljava/lang/String;
    .registers 1
    const-string v0, "state persisted"
    return-object v0
.end method
